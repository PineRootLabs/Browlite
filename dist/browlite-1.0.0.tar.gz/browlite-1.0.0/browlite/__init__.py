__version__ = "1.0.0"
__author__ = "PineRootLabs"
__license__ = "MIT"

from .main import Browlite, main